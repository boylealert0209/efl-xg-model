"""
build_team_workbook.py

Purpose
-------
Turn team_match_deltas.csv (one row per team per match, from build_deltas.py),
the raw results file (E1/E2/E3/... .csv, from download_results.py), and
optionally an upcoming-fixtures pre-match xG file (from download_fixtures.py
+ derive_prematch_xg.py) into one Excel workbook. League-agnostic — works for
any league whose CSVs you point it at (no --league flag needed here):

  - "About This Report" - a short front page explaining every sheet and the
                          handful of judgement calls made where the brief
                          for this report was ambiguous (sort order, what
                          "supremacy" means, etc.) - read this first.
  - "League Table"       - standard standings (P/W/D/L/GF/GA/GD/Pts) built
                          from every played match in the results file, via
                          formulas against a backing "Results Data" sheet.
  - "Overview"            - every team's core season xG/xPts form (a
                          deliberately narrow at-a-glance summary - see
                          write_overview_sheet's docstring for what's
                          left off and why), via formulas against each
                          team's own sheet. Sorted by Avg xG Delta (For),
                          best first.
  - "Home & Away Splits"  - league-wide Total/Home/Away breakdown of average
                          + median supremacy, and Total/Home/Away goals for
                          and against, one row per team.
  - "Supremacy Delta"     - grid: every team down the left, one column per
                          match, showing how much their actual xG supremacy
                          (actual for - actual against) beat or missed their
                          pre-match expected supremacy (pre-match for -
                          pre-match against). Sorted by its own average,
                          highest first.
  - "Supremacy Delta (Home)" / "Supremacy Delta (Away)" - the same grid,
                          restricted to each team's home-only / away-only
                          matches, each sorted by its own (home-only /
                          away-only) average rather than the main grid's.
  - "Total xG Delta"      - same grid layout, for how much higher/lower
                          scoring (by combined xG) each match was than the
                          pre-match market expected, regardless of who
                          scored it. Colour-scaled (green = higher-scoring
                          than expected, red = lower), sorted by average,
                          highest first, with a Median column at the end.
  - "xPts Delta"          - same grid layout again, for expected-points
                          over/under-performance (xPts Delta from
                          build_deltas.py's add_expected_points) per match.
                          Sorted by average, highest first.
  - "Upcoming Fixtures"   - only written if a fixtures pre-match xG file is
                          passed with --fixtures. Every fixture the market
                          has odds for right now, ranked by an "expected
                          supremacy" that blends the market's own pre-match
                          view of that fixture with how much each side has
                          been over/under-performing their own expectation
                          all season (see the About sheet for the exact
                          formula).
  - one sheet per team    - full match log: goals, pre-match market xG,
                          post-match actual xG, deltas, rolling form,
                          Supremacy Delta, Match Total xG Delta; a season
                          summary block (average AND median of every delta
                          stat); and a Home/Away split mini-table.

"MW1/MW2/..." (and "H1/H2.../A1/A2...") are each team's own 1st, 2nd, 3rd...
match of the season (or of that venue) in date order - not the officially
numbered fixture-list gameweek, since that's not in the source data and
postponed/rearranged games can knock a team's Nth match out of sync with the
calendar week. For a normal run of fixtures they line up; see the cell
comment on each grid's "Team" header.

Usage
-----
    python build_team_workbook.py \
        --input data/team_match_deltas_league-one.csv \
        --results data/E2.csv \
        --fixtures data/prematch_xg_fixtures_league-one.csv \
        --output data/league-one_xg_report.xlsx \
        --rolling-window 6

--fixtures is optional - omit it (or pass '') and the workbook is built
without an "Upcoming Fixtures" sheet, same as before this feature existed.
The --rolling-window value only needs to match whatever you passed to
build_deltas.py if you want the "current form" labels to show the right
number - it doesn't recompute anything.
"""

import argparse
import re
import sys
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.chart import BarChart, LineChart, Reference

# Reuse the same team-name normalisation as build_deltas.py, so every sheet
# (built from E1.csv-style naming, e.g. "QPR") uses the same names as the
# team tabs (built from team_match_deltas.csv, already normalised).
sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_deltas import TEAM_NAME_MAP, normalise_name

FONT_NAME = "Arial"
HEADER_FILL = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
HEADER_FONT = Font(name=FONT_NAME, bold=True, color="FFFFFF")
BODY_FONT = Font(name=FONT_NAME)
BOLD_FONT = Font(name=FONT_NAME, bold=True)
TITLE_FONT = Font(name=FONT_NAME, bold=True, size=16, color="1F4E78")
SUBTITLE_FONT = Font(name=FONT_NAME, italic=True, size=10, color="595959")
SUMMARY_FILL = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
BAND_FILL = PatternFill(start_color="F2F6FA", end_color="F2F6FA", fill_type="solid")
SECTION_FILL = PatternFill(start_color="8EA9C1", end_color="8EA9C1", fill_type="solid")
THIN = Side(style="thin", color="BFBFBF")
THIN_BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

GREEN = "63BE7B"
RED = "F8696B"
WHITE = "FFFFFF"
AMBER = "FFC000"
GREY = "D9D9D9"

# Win / draw / defeat fills for the closing-odds table on each team tab.
RESULT_FILLS = {
    "W": PatternFill(start_color=GREEN, end_color=GREEN, fill_type="solid"),
    "D": PatternFill(start_color=AMBER, end_color=AMBER, fill_type="solid"),
    "L": PatternFill(start_color=RED, end_color=RED, fill_type="solid"),
}
GREY_FILL = PatternFill(start_color=GREY, end_color=GREY, fill_type="solid")

# Closing-odds columns in the football-data.co.uk results files, in order of
# preference: Pinnacle closing (the sharpest market), then the market-average
# closing price, then Bet365 closing. The first pair with both a home and an
# away price on a given row is used for that row.
CLOSING_ODDS_COLS = [("PPCH", "PPCD", "PPCA"), ("AvgCH", "AvgCD", "AvgCA"), ("B365CH", "B365CD", "B365CA")]

# Column headers for each team's match-log table, in order, mapped to the
# team_match_deltas.csv column they come from. "supremacy_delta" and
# "total_xg_delta" are computed in Excel from the other columns on the same
# row, not read from the CSV.
MATCH_COLUMNS = [
    ("Date", "date"),
    ("Opponent", "opponent"),
    ("Venue", "venue"),
    ("Goals For", "goals_for"),
    ("Goals Against", "goals_against"),
    ("xG Pre-Match (For)", "xg_pre_market_for"),
    ("xG Pre-Match (Against)", "xg_pre_market_against"),
    ("xG Actual (For)", "xg_actual_for"),
    ("xG Actual (Against)", "xg_actual_against"),
    ("xG Delta (For)", "xg_delta_for"),
    ("xG Delta (Against)", "xg_delta_against"),
    ("Rolling Delta (For)", "xg_delta_for_rolling"),
    ("Rolling Delta (Against)", "xg_delta_against_rolling"),
    # Opponent-strength-adjusted deltas (from build_deltas.py's
    # add_opponent_adjustment): xg_delta_for adjusted for how well this
    # opponent generally defends, and xg_delta_against adjusted for how
    # well this opponent generally attacks. NaN for a team's first match
    # against a given opponent (not enough history yet to estimate that
    # opponent's own strength) - shown blank rather than 0.
    ("xG Delta (For, Adj)", "xg_delta_for_adj"),
    ("xG Delta (Against, Adj)", "xg_delta_against_adj"),
    ("Rolling Delta (For, Adj)", "xg_delta_for_adj_rolling"),
    ("Rolling Delta (Against, Adj)", "xg_delta_against_adj_rolling"),
    ("Supremacy Delta", "supremacy_delta"),
    ("Match Total xG Delta", "total_xg_delta"),
    # Expected points (from build_deltas.py's add_expected_points): deserved
    # points from this match's actual (shot-based) xG vs. from the pre-match
    # market xG, via an independent-Poisson scoreline model. Cumulative
    # columns are a running season total in date order - the "xPts table"
    # sheet uses each team's final cumulative value.
    ("xPts (Actual)", "xpts_actual"),
    ("xPts (Market)", "xpts_market"),
    ("xPts Delta", "xpts_delta"),
    ("xPts (Actual, Cum.)", "xpts_actual_cumulative"),
    ("xPts (Market, Cum.)", "xpts_market_cumulative"),
]

MW_NOTE = ('"MW" here means this team\'s own 1st, 2nd, 3rd... match of the '
           "season in date order - not the official league gameweek number. "
           "They usually line up, but postponed/rearranged fixtures can "
           "knock a team's Nth match out of sync with the calendar week.")

ABOUT_NOTE = (
    "Where the brief for this report left a choice open, this workbook "
    "makes one consistently rather than guessing differently sheet to "
    "sheet - see the About This Report sheet for exactly which calls "
    "were made (sort orders, what \"expected supremacy\" means for "
    "upcoming fixtures, etc.)."
)


def round_or_none(x, ndigits=2):
    """round() a possibly-NaN value, returning None (blank cell) for NaN
    instead of the string 'nan' openpyxl would otherwise write."""
    return None if pd.isna(x) else round(x, ndigits)


def safe_sheet_name(name: str, used: set) -> str:
    """Excel sheet names: <=31 chars, no \\ / ? * [ ] :, and unique."""
    cleaned = re.sub(r"[\\/?*\[\]:]", "", name)[:31]
    candidate = cleaned
    n = 2
    while candidate in used:
        suffix = f" ({n})"
        candidate = cleaned[: 31 - len(suffix)] + suffix
        n += 1
    used.add(candidate)
    return candidate


def style_header_row(ws: Worksheet, row: int, n_cols: int):
    for col in range(1, n_cols + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center", wrap_text=True, vertical="center")
        cell.border = THIN_BORDER
    ws.row_dimensions[row].height = 30


def color_scale(ws: Worksheet, rng: str, invert: bool):
    """Percentile-based scale: invert=False: low=red, high=green (use where
    higher is better). invert=True: low=green, high=red (use where a
    lower/more negative number is the good outcome, e.g. conceding less
    than expected)."""
    low, high = (GREEN, RED) if invert else (RED, GREEN)
    ws.conditional_formatting.add(
        rng,
        ColorScaleRule(
            start_type="min", start_color=low,
            mid_type="percentile", mid_value=50, mid_color=WHITE,
            end_type="max", end_color=high,
        ),
    )


def color_scale_zero(ws: Worksheet, rng: str, invert: bool = False):
    """Zero-anchored scale for delta-style stats where 0 = "exactly as
    expected" is meaningful on its own, not just relative to the rest of
    the column: positive -> shades of green, negative -> shades of red,
    with white pinned at zero itself (not the column's median/percentile,
    which is what plain color_scale() above anchors to). invert=True flips
    it for stats where negative is the good outcome (e.g. "Against" columns
    - conceding less than expected)."""
    low, high = (GREEN, RED) if invert else (RED, GREEN)
    ws.conditional_formatting.add(
        rng,
        ColorScaleRule(
            start_type="min", start_color=low,
            mid_type="num", mid_value=0, mid_color=WHITE,
            end_type="max", end_color=high,
        ),
    )


def autosize_columns(ws: Worksheet, n_cols: int, header_row: int = 1, min_width=4, max_width=24,
                      max_row=None, width_hints: dict | None = None):
    """Width fits the DISPLAYED data in each column, not the header and not
    a formula's literal text (e.g. '=(H2+I2)-(F2+G2)' is 17 characters but
    might display '-1.53' - 5 characters). For columns of literal values
    this is scanned straight from the cells; for formula columns, pass
    width_hints = {1-indexed column: [list of the numbers/strings that
    formula will evaluate to]} computed from the same Python data the
    formula reads, since we can't run Excel here to find out what it
    displays.

    Also considers the header cell's own text length - a short numeric
    column (e.g. "-1.53") under a long header ("Home Median") was
    otherwise sized to the data alone and left the header truncated."""
    max_row = max_row if max_row is not None else ws.max_row
    width_hints = width_hints or {}
    for col in range(1, n_cols + 1):
        letter = get_column_letter(col)
        if col in width_hints and width_hints[col]:
            longest = max(len(str(v)) for v in width_hints[col])
        else:
            longest = max(
                (len(str(ws.cell(row=r, column=col).value))
                 for r in range(header_row + 1, max_row + 1)
                 if ws.cell(row=r, column=col).value is not None),
                default=min_width,
            )
        header_value = ws.cell(row=header_row, column=col).value
        if header_value is not None:
            longest = max(longest, len(str(header_value)))
        ws.column_dimensions[letter].width = max(min_width, min(max_width, longest + 1))


def polish_sheet(ws: Worksheet, header_row: int, first_data_row: int, last_data_row: int, n_cols: int,
                  band: bool = True):
    """Shared professional-look pass, applied after a sheet's data is
    written: no gridlines (the borders below give structure instead), a
    thin border around every header/data cell, and (optionally) very light
    banding on alternate data rows so wide tables stay readable. Doesn't
    touch fonts/number formats - those are set per-sheet since they vary."""
    ws.sheet_view.showGridLines = False
    for col in range(1, n_cols + 1):
        ws.cell(row=header_row, column=col).border = THIN_BORDER
    for row in range(first_data_row, last_data_row + 1):
        for col in range(1, n_cols + 1):
            cell = ws.cell(row=row, column=col)
            cell.border = THIN_BORDER
            if band and cell.fill.start_color.rgb in (None, "00000000") and (row - first_data_row) % 2 == 1:
                cell.fill = BAND_FILL


def stat_block(series: pd.Series) -> dict:
    """Average + median for a pandas Series, rounded, with a safe fallback
    (0.0) for an empty series (e.g. a team with no away matches yet)."""
    if len(series) == 0:
        return {"avg": 0.0, "median": 0.0}
    return {"avg": round(float(series.mean()), 2), "median": round(float(series.median()), 2)}


def write_team_sheet(wb: Workbook, sheet_name: str, team_df: pd.DataFrame, rolling_window: int,
                     odds_lookup: dict | None = None, table_order: list | None = None):
    """Returns a dict of everything the Overview/Home & Away Splits/grid
    sheets need to reference this team's data by formula or by value:
        sheet_name, n_matches, col_letter (header -> column letter),
        summary_rows (label -> row number in the season-summary block),
        stats (plain-Python season/home/away summary numbers)."""
    ws = wb.create_sheet(sheet_name)
    team_df = team_df.sort_values("date").reset_index(drop=True)

    headers = [h for h, _ in MATCH_COLUMNS]
    n_cols = len(headers)
    ws.append(headers)
    style_header_row(ws, 1, n_cols)

    col_letter = {h: get_column_letter(i + 1) for i, (h, _) in enumerate(MATCH_COLUMNS)}
    supremacy_col = [h for h, _ in MATCH_COLUMNS].index("Supremacy Delta") + 1
    total_delta_col = [h for h, _ in MATCH_COLUMNS].index("Match Total xG Delta") + 1
    supremacy_hints, total_delta_hints = [], []

    pf, pa = col_letter["xG Pre-Match (For)"], col_letter["xG Pre-Match (Against)"]
    af, aa = col_letter["xG Actual (For)"], col_letter["xG Actual (Against)"]

    # Computed once here (not read back from the CSV) so the season-summary
    # block, the Home/Away split table, and this team's contribution to the
    # league-wide sheets all agree with what's actually on the rows above.
    supremacy_full = ((team_df["xg_actual_for"] - team_df["xg_actual_against"])
                       - (team_df["xg_pre_market_for"] - team_df["xg_pre_market_against"])).round(2)
    total_full = ((team_df["xg_actual_for"] + team_df["xg_actual_against"])
                  - (team_df["xg_pre_market_for"] + team_df["xg_pre_market_against"])).round(2)

    for row_i, (_, r) in enumerate(team_df.iterrows(), start=2):
        row_values = []
        for header, col in MATCH_COLUMNS:
            if col == "supremacy_delta":
                # (actual for - actual against) - (pre-match for - pre-match
                # against): how much the team's actual xG superiority over
                # their opponent beat (positive) or missed (negative) what
                # the market expected that superiority to be.
                row_values.append(f"=({af}{row_i}-{aa}{row_i})-({pf}{row_i}-{pa}{row_i})")
                supremacy_hints.append(supremacy_full.iloc[row_i - 2])
                continue
            if col == "total_xg_delta":
                # (actual for + actual against) - (pre-match for + pre-match
                # against): how much higher/lower-scoring (by xG) this match
                # was than the market expected, regardless of which side.
                row_values.append(f"=({af}{row_i}+{aa}{row_i})-({pf}{row_i}+{pa}{row_i})")
                total_delta_hints.append(total_full.iloc[row_i - 2])
                continue
            val = r[col]
            if col == "date":
                val = pd.to_datetime(val).strftime("%Y-%m-%d")
            elif col == "venue":
                val = str(val).title()
            elif isinstance(val, float):
                val = None if pd.isna(val) else round(val, 2)
            row_values.append(val)
        ws.append(row_values)

    last_row = ws.max_row
    n_matches = last_row - 1
    decimal_cols = {i + 1 for i, (_, col) in enumerate(MATCH_COLUMNS)
                     if col not in ("date", "opponent", "venue", "goals_for", "goals_against")}
    for row in ws.iter_rows(min_row=2, max_row=last_row, max_col=n_cols):
        for cell in row:
            cell.font = BODY_FONT
            if cell.column in decimal_cols:
                cell.number_format = "0.00"

    # Colour-scale every delta column, zero-anchored (0 = exactly as
    # expected) rather than relative to the column's own spread. "(For)"
    # and "Supremacy Delta": green = better than expected (higher).
    # "(Against)" columns: green = better than expected (LOWER / more
    # negative - conceded less than expected). "Match Total xG Delta" is
    # coloured too now (green = higher-scoring match than the market
    # expected, red = lower) - it's a fact about the match rather than a
    # team performance stat, but still meaningfully signed around zero.
    for header in ("xG Delta (For)", "Rolling Delta (For)",
                   "xG Delta (For, Adj)", "Rolling Delta (For, Adj)", "Supremacy Delta"):
        letter = col_letter[header]
        color_scale_zero(ws, f"{letter}2:{letter}{last_row}", invert=False)
    for header in ("xG Delta (Against)", "Rolling Delta (Against)",
                   "xG Delta (Against, Adj)", "Rolling Delta (Against, Adj)"):
        letter = col_letter[header]
        color_scale_zero(ws, f"{letter}2:{letter}{last_row}", invert=True)
    letter = col_letter["Match Total xG Delta"]
    color_scale_zero(ws, f"{letter}2:{letter}{last_row}", invert=False)
    letter = col_letter["xPts Delta"]
    color_scale_zero(ws, f"{letter}2:{letter}{last_row}", invert=False)

    # Summary block: real formulas over the table above, not re-typed
    # numbers, so it stays correct if you ever edit a row by hand. Labels
    # are merged across A:D and the value sits in E, so long label text
    # doesn't force the narrow Date/Opponent/Venue/Goals columns wide.
    summary_row = last_row + 2
    ws.cell(row=summary_row, column=1, value="Season summary").font = BOLD_FONT

    def col_range(header_name):
        letter = col_letter[header_name]
        return f"{letter}2:{letter}{last_row}"

    labels_formulas = [
        ("Matches played", f"=COUNTA({col_range('Date')})", True),
        ("Total goals for", f"=SUM({col_range('Goals For')})", True),
        ("Total goals against", f"=SUM({col_range('Goals Against')})", True),
        ("Avg xG Delta (For)", f"=AVERAGE({col_range('xG Delta (For)')})", False),
        ("Median xG Delta (For)", f"=MEDIAN({col_range('xG Delta (For)')})", False),
        ("Avg xG Delta (Against)", f"=AVERAGE({col_range('xG Delta (Against)')})", False),
        ("Median xG Delta (Against)", f"=MEDIAN({col_range('xG Delta (Against)')})", False),
        # AVERAGE/MEDIAN skip blank cells automatically, so the (Adj)
        # columns' blanks (a team's first meeting with a given opponent -
        # no history yet to gauge that opponent's strength) don't need
        # special-casing here.
        ("Avg xG Delta (For, Adj)", f"=AVERAGE({col_range('xG Delta (For, Adj)')})", False),
        ("Median xG Delta (For, Adj)", f"=MEDIAN({col_range('xG Delta (For, Adj)')})", False),
        ("Avg xG Delta (Against, Adj)", f"=AVERAGE({col_range('xG Delta (Against, Adj)')})", False),
        ("Median xG Delta (Against, Adj)", f"=MEDIAN({col_range('xG Delta (Against, Adj)')})", False),
        ("Avg Supremacy Delta", f"=AVERAGE({col_range('Supremacy Delta')})", False),
        ("Median Supremacy Delta", f"=MEDIAN({col_range('Supremacy Delta')})", False),
        ("Avg Total xG Delta", f"=AVERAGE({col_range('Match Total xG Delta')})", False),
        ("Median Total xG Delta", f"=MEDIAN({col_range('Match Total xG Delta')})", False),
        (f"Current form (last {rolling_window}, For)", f"={col_letter['Rolling Delta (For)']}{last_row}", False),
        (f"Current form (last {rolling_window}, Against)", f"={col_letter['Rolling Delta (Against)']}{last_row}", False),
        (f"Current form (last {rolling_window}, For, Adj)", f"={col_letter['Rolling Delta (For, Adj)']}{last_row}", False),
        (f"Current form (last {rolling_window}, Against, Adj)", f"={col_letter['Rolling Delta (Against, Adj)']}{last_row}", False),
        # SUM (not AVERAGE) here, deliberately - a season TOTAL of deserved
        # points, comparable to the real League Table's Pts column, not a
        # per-match average.
        ("Total xPts (Actual)", f"=SUM({col_range('xPts (Actual)')})", False),
        ("Total xPts (Market)", f"=SUM({col_range('xPts (Market)')})", False),
        ("Avg xPts Delta", f"=AVERAGE({col_range('xPts Delta')})", False),
    ]
    summary_rows = {}
    for i, (label, formula, is_integer) in enumerate(labels_formulas):
        r = summary_row + 1 + i
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
        label_cell = ws.cell(row=r, column=1, value=label)
        label_cell.font = BODY_FONT
        value_cell = ws.cell(row=r, column=5, value=formula)
        value_cell.font = BODY_FONT
        value_cell.fill = SUMMARY_FILL
        value_cell.number_format = "0" if is_integer else "0.00"
        summary_rows[label] = r

    # Home / Away split mini-table: literal values (computed in Python from
    # the rows above), not formulas - a MEDIAN-of-a-condition needs an
    # array formula that's fragile across Excel versions, and these three
    # rows are a read-only snapshot rather than something you'd hand-edit.
    home_mask = team_df["venue"] == "home"
    away_mask = team_df["venue"] == "away"
    split_row = summary_rows[labels_formulas[-1][0]] + 2
    ws.cell(row=split_row, column=1, value="Home / Away split").font = BOLD_FONT
    split_headers = ["Venue", "Matches", "GF", "GA", "Avg Supremacy", "Median Supremacy",
                      "Avg Total xG Delta", "Median Total xG Delta"]
    for c, h in enumerate(split_headers, start=1):
        cell = ws.cell(row=split_row + 1, column=c, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center", wrap_text=True)

    home_split = stat_block(supremacy_full[home_mask])
    away_split = stat_block(supremacy_full[away_mask])
    home_total_split = stat_block(total_full[home_mask])
    away_total_split = stat_block(total_full[away_mask])
    venue_rows = [
        ("Home", int(home_mask.sum()), int(team_df.loc[home_mask, "goals_for"].sum()),
         int(team_df.loc[home_mask, "goals_against"].sum()),
         home_split["avg"], home_split["median"], home_total_split["avg"], home_total_split["median"]),
        ("Away", int(away_mask.sum()), int(team_df.loc[away_mask, "goals_for"].sum()),
         int(team_df.loc[away_mask, "goals_against"].sum()),
         away_split["avg"], away_split["median"], away_total_split["avg"], away_total_split["median"]),
        ("Total", n_matches, int(team_df["goals_for"].sum()), int(team_df["goals_against"].sum()),
         stat_block(supremacy_full)["avg"], stat_block(supremacy_full)["median"],
         stat_block(total_full)["avg"], stat_block(total_full)["median"]),
    ]
    for r_off, row_vals in enumerate(venue_rows, start=1):
        r = split_row + 1 + r_off
        for c, v in enumerate(row_vals, start=1):
            cell = ws.cell(row=r, column=c, value=v)
            cell.font = BOLD_FONT if row_vals[0] == "Total" else BODY_FONT
            if c >= 5:
                cell.number_format = "0.00"
            if row_vals[0] == "Total":
                cell.fill = SUMMARY_FILL

    ws.freeze_panes = "A2"
    # Width is based only on the match-table rows (not the summary/split
    # blocks below, whose labels live in their own header row) so the data
    # columns stay narrow - just wide enough for the numbers. Formula
    # columns get their width from the actual numbers they'll evaluate to
    # (computed here in Python), not the formula text itself.
    autosize_columns(ws, n_cols, header_row=1, max_row=last_row, width_hints={
        supremacy_col: supremacy_hints,
        total_delta_col: total_delta_hints,
    })
    polish_sheet(ws, header_row=1, first_data_row=2, last_data_row=last_row, n_cols=n_cols)

    # Goals-vs-expected chart, over/under-expected counts and the closing-odds
    # table - all to the right of the match table (see write_team_extras).
    write_team_extras(ws, str(team_df["team"].iloc[0]), n_cols, n_matches, last_row, col_letter,
                       odds_lookup, table_order)

    stats = {
        "matches": n_matches,
        "gf": int(team_df["goals_for"].sum()),
        "ga": int(team_df["goals_against"].sum()),
        "avg_for": round(team_df["xg_delta_for"].mean(), 2),
        "median_for": round(team_df["xg_delta_for"].median(), 2),
        "avg_against": round(team_df["xg_delta_against"].mean(), 2),
        "median_against": round(team_df["xg_delta_against"].median(), 2),
        "form_for": round(team_df["xg_delta_for_rolling"].iloc[-1], 2),
        "form_against": round(team_df["xg_delta_against_rolling"].iloc[-1], 2),
        # .mean()/.median() skip NaNs already; only the final round() needs
        # a NaN guard, for the (rare) case a team's played too few distinct
        # opponents for any adjusted value to exist yet.
        "avg_for_adj": round_or_none(team_df["xg_delta_for_adj"].mean()),
        "median_for_adj": round_or_none(team_df["xg_delta_for_adj"].median()),
        "avg_against_adj": round_or_none(team_df["xg_delta_against_adj"].mean()),
        "median_against_adj": round_or_none(team_df["xg_delta_against_adj"].median()),
        "form_for_adj": round_or_none(team_df["xg_delta_for_adj_rolling"].iloc[-1]),
        "form_against_adj": round_or_none(team_df["xg_delta_against_adj_rolling"].iloc[-1]),
        "total_xpts_actual": round(team_df["xpts_actual"].sum(), 2),
        "total_xpts_market": round(team_df["xpts_market"].sum(), 2),
        "avg_xpts_delta": round(team_df["xpts_delta"].mean(), 2),
        "avg_supremacy": stat_block(supremacy_full)["avg"],
        "median_supremacy": stat_block(supremacy_full)["median"],
        "avg_total_delta": stat_block(total_full)["avg"],
        "median_total_delta": stat_block(total_full)["median"],
        "home_matches": int(home_mask.sum()),
        "home_gf": int(team_df.loc[home_mask, "goals_for"].sum()),
        "home_ga": int(team_df.loc[home_mask, "goals_against"].sum()),
        "home_avg_supremacy": home_split["avg"],
        "home_median_supremacy": home_split["median"],
        "away_matches": int(away_mask.sum()),
        "away_gf": int(team_df.loc[away_mask, "goals_for"].sum()),
        "away_ga": int(team_df.loc[away_mask, "goals_against"].sum()),
        "away_avg_supremacy": away_split["avg"],
        "away_median_supremacy": away_split["median"],
    }

    return {
        "sheet_name": sheet_name,
        "n_matches": n_matches,
        "col_letter": col_letter,
        "summary_rows": summary_rows,
        "stats": stats,
        # Full-season / home-only / away-only supremacy & total-delta
        # series in date order, for the league-wide grid sheets.
        "supremacy_series": supremacy_full.tolist(),
        "total_series": total_full.tolist(),
        "home_supremacy_series": supremacy_full[home_mask].tolist(),
        "away_supremacy_series": supremacy_full[away_mask].tolist(),
        "xpts_delta_series": team_df["xpts_delta"].tolist(),
    }


def write_overview_sheet(wb: Workbook, team_info: dict, rolling_window: int):
    """Ranks every team by Avg xG Delta (For), best first - see the About
    This Report sheet for why "in order of xG for" was read that way.

    Deliberately narrower than the full picture: medians, the Adjusted
    current-form pair, goal totals (already on League Table) and Avg
    Total xG Delta (already its own grid sheet) are left off so this
    reads as an at-a-glance summary rather than a second data dump -
    the team tabs and the dedicated grid sheets still have the detail."""
    ws = wb.create_sheet("Overview")
    headers = [
        "Team", "Matches Played",
        "Avg xG Delta (For)", "Avg xG Delta (Against)",
        "Avg xG Delta (For, Adj)", "Avg xG Delta (Against, Adj)",
        "Avg Supremacy Delta",
        f"Current Form ({rolling_window}, For)", f"Current Form ({rolling_window}, Against)",
        "Total xPts (Actual)", "Total xPts (Market)", "Avg xPts Delta",
    ]
    ws.append(headers)
    style_header_row(ws, 1, len(headers))

    row_order = sorted(team_info.keys(), key=lambda t: team_info[t]["stats"]["avg_for"], reverse=True)

    stat_keys = ["matches", "avg_for", "avg_against", "avg_for_adj", "avg_against_adj",
                 "avg_supremacy", "form_for", "form_against",
                 "total_xpts_actual", "total_xpts_market", "avg_xpts_delta"]
    width_hints = {i + 2: [] for i in range(len(stat_keys))}
    for team in row_order:
        info = team_info[team]
        sheet_name, sr, s = info["sheet_name"], info["summary_rows"], info["stats"]
        row_labels = [
            "Matches played",
            "Avg xG Delta (For)", "Avg xG Delta (Against)",
            "Avg xG Delta (For, Adj)", "Avg xG Delta (Against, Adj)",
            "Avg Supremacy Delta",
            f"Current form (last {rolling_window}, For)", f"Current form (last {rolling_window}, Against)",
            "Total xPts (Actual)", "Total xPts (Market)", "Avg xPts Delta",
        ]
        ws.append([team] + [f"='{sheet_name}'!$E${sr[lbl]}" for lbl in row_labels])
        for i, key in enumerate(stat_keys):
            width_hints[i + 2].append(s[key])

    last_row = ws.max_row
    decimal_overview_cols = set(range(3, len(headers) + 1))
    for row in ws.iter_rows(min_row=2, max_row=last_row, max_col=len(headers)):
        for cell in row:
            cell.font = BODY_FONT
            if cell.column in decimal_overview_cols:
                cell.number_format = "0.00"

    zero_centered_cols = {
        3: False,   # xG Delta (For): higher = better
        4: True,    # xG Delta (Against): lower = better
        5: False,   # xG Delta (For, Adj): higher = better
        6: True,    # xG Delta (Against, Adj): lower = better
        7: False,   # Supremacy Delta: higher = better
        8: False, 9: True,   # Current form For/Against
        12: False,  # Avg xPts Delta: higher = better, zero-anchored (Total xPts cols 10/11 are
                     # left uncoloured, like Total Goals For/Against - a plain positive total,
                     # not a delta, so a zero-anchored scale would just paint everything green)
    }
    for col_idx, invert in zero_centered_cols.items():
        col_letter = get_column_letter(col_idx)
        color_scale_zero(ws, f"{col_letter}2:{col_letter}{last_row}", invert=invert)

    ws.freeze_panes = "A2"
    autosize_columns(ws, len(headers), width_hints=width_hints)
    ws.column_dimensions["A"].width = max(ws.column_dimensions["A"].width, 14)  # Team
    polish_sheet(ws, header_row=1, first_data_row=2, last_data_row=last_row, n_cols=len(headers))


def write_xpts_table_sheet(wb: Workbook, team_info: dict):
    """The "truer league table" from the brief: teams ranked by season-total
    expected points (deserved points from actual shot-based xG, via an
    independent-Poisson scoreline model - see build_deltas.py's
    add_expected_points), alongside what the market expected them to earn,
    rather than by the actual (bounce-of-the-ball) results. Pos is by xPts
    Delta (Total) descending - i.e. who has most over/under-performed the
    market's own expectation, not just who has the most deserved points
    outright (a team can rank high on raw xPts just by playing a lot of
    matches or being a good team the market already rates highly - the
    delta is the more interesting "who's exceeding expectation" cut).
    There's no goal-difference-style tiebreak here since the delta is
    already a continuous number, ties are vanishingly rare."""
    ws = wb.create_sheet("xPts Table")
    headers = ["Pos", "Team", "Matches", "xPts (Actual)", "xPts (Market)", "xPts Delta (Total)"]
    ws.append(headers)
    style_header_row(ws, 1, len(headers))

    row_order = sorted(team_info.keys(),
                        key=lambda t: team_info[t]["stats"]["total_xpts_actual"]
                        - team_info[t]["stats"]["total_xpts_market"], reverse=True)

    width_hints = {3: [], 4: [], 5: [], 6: []}
    for pos, team in enumerate(row_order, start=1):
        info = team_info[team]
        sheet_name, sr, s = info["sheet_name"], info["summary_rows"], info["stats"]
        actual_row = sr["Total xPts (Actual)"]
        market_row = sr["Total xPts (Market)"]
        actual_ref = f"='{sheet_name}'!$E${actual_row}"
        market_ref = f"='{sheet_name}'!$E${market_row}"
        r = ws.max_row + 1
        ws.cell(row=r, column=1, value=pos)
        ws.cell(row=r, column=2, value=team)
        ws.cell(row=r, column=3, value=f"='{sheet_name}'!$E${sr['Matches played']}")
        ws.cell(row=r, column=4, value=actual_ref)
        ws.cell(row=r, column=5, value=market_ref)
        ws.cell(row=r, column=6, value=f"=D{r}-E{r}")
        width_hints[3].append(s["matches"])
        width_hints[4].append(s["total_xpts_actual"])
        width_hints[5].append(s["total_xpts_market"])
        width_hints[6].append(round(s["total_xpts_actual"] - s["total_xpts_market"], 2))

    last_row = ws.max_row
    for row in ws.iter_rows(min_row=2, max_row=last_row, max_col=len(headers)):
        for cell in row:
            cell.font = BODY_FONT
            if cell.column == 1:
                cell.alignment = Alignment(horizontal="center")
            if cell.column in (4, 5, 6):
                cell.number_format = "0.00"

    color_scale_zero(ws, f"F2:F{last_row}", invert=False)  # xPts Delta (Total): higher = better

    ws.freeze_panes = "A2"
    autosize_columns(ws, len(headers), width_hints=width_hints)
    ws.column_dimensions["B"].width = max(ws.column_dimensions["B"].width, 14)  # Team
    polish_sheet(ws, header_row=1, first_data_row=2, last_data_row=last_row, n_cols=len(headers))


def build_match_log(df: pd.DataFrame) -> pd.DataFrame:
    """Reshape team_match_deltas.csv (one row per team per match) into one
    row per FIXTURE - the "single master data table" from the brief.

    Every number on this sheet is already duplicated across two rows in
    df (the home team's row and the away team's mirror row - see
    build_deltas.py's to_long_form), so this is a join back to itself on
    (date, home_team, away_team), not new data - it doesn't reduce the
    duplication in df, but gives one authoritative row per match instead
    of forcing you to remember "home team's row" vs "away team's row"."""
    home = df[df["venue"] == "home"].rename(columns={"team": "home_team", "opponent": "away_team"})
    away = df[df["venue"] == "away"].rename(columns={"team": "away_team", "opponent": "home_team"})
    merged = pd.merge(
        home, away, on=["date", "home_team", "away_team"], suffixes=("_home", "_away"),
    )
    merged = merged.sort_values("date").reset_index(drop=True)
    return merged


def write_match_log_sheet(wb: Workbook, match_log: pd.DataFrame):
    """One row per fixture across every team, with an AutoFilter so you can
    filter by opponent/venue/matchweek etc. without touching a pivot table
    or a team tab. A basic AutoFilter (rather than a formal Excel Table
    object) was used deliberately - Excel Tables/Slicers don't always
    survive Google Sheets' xlsx import cleanly, while a plain AutoFilter
    does; add a Table/Slicer over this range by hand in Excel if you're
    staying in Excel."""
    ws = wb.create_sheet("Match Log")

    headers = [
        "Date", "Home Team", "Away Team", "Home Goals", "Away Goals",
        "Home xG Pre-Match", "Away xG Pre-Match", "Home xG Actual", "Away xG Actual",
        "Home xG Delta", "Away xG Delta", "Supremacy Delta (Home)", "Total xG Delta",
        "Home xPts (Actual)", "Away xPts (Actual)", "Home xPts (Market)", "Away xPts (Market)",
    ]
    ws.append(headers)
    style_header_row(ws, 1, len(headers))

    supremacy_full = ((match_log["xg_actual_for_home"] - match_log["xg_actual_against_home"])
                       - (match_log["xg_pre_market_for_home"] - match_log["xg_pre_market_against_home"])).round(2)
    total_full = ((match_log["xg_actual_for_home"] + match_log["xg_actual_against_home"])
                  - (match_log["xg_pre_market_for_home"] + match_log["xg_pre_market_against_home"])).round(2)

    for i, r in match_log.iterrows():
        ws.append([
            pd.to_datetime(r["date"]).strftime("%Y-%m-%d"),
            r["home_team"], r["away_team"],
            int(r["goals_for_home"]), int(r["goals_for_away"]),
            round(r["xg_pre_market_for_home"], 2), round(r["xg_pre_market_for_away"], 2),
            round(r["xg_actual_for_home"], 2), round(r["xg_actual_for_away"], 2),
            round(r["xg_delta_for_home"], 2), round(r["xg_delta_for_away"], 2),
            supremacy_full.iloc[i], total_full.iloc[i],
            round(r["xpts_actual_home"], 2), round(r["xpts_actual_away"], 2),
            round(r["xpts_market_home"], 2), round(r["xpts_market_away"], 2),
        ])

    last_row = ws.max_row
    n_cols = len(headers)
    decimal_cols = set(range(6, n_cols + 1))
    for row in ws.iter_rows(min_row=2, max_row=last_row, max_col=n_cols):
        for cell in row:
            cell.font = BODY_FONT
            if cell.column in decimal_cols:
                cell.number_format = "0.00"

    for header in ("Home xG Delta", "Away xG Delta", "Supremacy Delta (Home)", "Total xG Delta"):
        letter = get_column_letter(headers.index(header) + 1)
        color_scale_zero(ws, f"{letter}2:{letter}{last_row}", invert=False)

    ws.auto_filter.ref = f"A1:{get_column_letter(n_cols)}{last_row}"
    ws.freeze_panes = "A2"
    autosize_columns(ws, n_cols, header_row=1, max_row=last_row)
    ws.column_dimensions["B"].width = max(ws.column_dimensions["B"].width, 14)
    ws.column_dimensions["C"].width = max(ws.column_dimensions["C"].width, 14)
    polish_sheet(ws, header_row=1, first_data_row=2, last_data_row=last_row, n_cols=n_cols)


def check_data_quality(match_log: pd.DataFrame) -> pd.DataFrame:
    """Flag per-fixture problems in the numbers actually feeding the
    workbook: missing xG/goals (usually a FotMob scrape that came back
    empty for that match), negative xG or goals (impossible - a sign a
    column got shifted or misread upstream), and exact-zero xG on both
    sides in the same match (technically valid but suspicious - more
    often a placeholder than a real 0.00-0.00 chance count).

    "Broken formulas" and "non-numeric text" from the brief aren't
    checked here because they can't reach this sheet in the first place:
    every column here came from a pandas CSV read that would already have
    raised (or coerced to NaN, which the missing-value check below already
    catches) if a cell weren't numeric - there's no live formula in this
    pipeline's data files for one to corrupt.

    Returns a DataFrame with one row per (fixture, issue) - a single
    fixture can appear more than once if it has several problems."""
    issues = []
    checks = [
        ("xg_pre_market_for_home", "Home pre-match xG"),
        ("xg_pre_market_for_away", "Away pre-match xG"),
        ("xg_actual_for_home", "Home actual xG"),
        ("xg_actual_for_away", "Away actual xG"),
        ("goals_for_home", "Home goals"),
        ("goals_for_away", "Away goals"),
    ]
    for _, r in match_log.iterrows():
        row_issues = []
        for col, label in checks:
            val = r[col]
            if pd.isna(val):
                row_issues.append(f"Missing {label}")
            elif val < 0:
                row_issues.append(f"Negative {label} ({val})")
        if pd.notna(r["xg_actual_for_home"]) and pd.notna(r["xg_actual_for_away"]) \
                and r["xg_actual_for_home"] == 0 and r["xg_actual_for_away"] == 0:
            row_issues.append("Both teams' actual xG are exactly 0.00 - worth checking the FotMob scrape for this match")
        for issue in row_issues:
            issues.append({"date": r["date"], "home_team": r["home_team"],
                            "away_team": r["away_team"], "issue": issue})

    dup_mask = match_log.duplicated(subset=["date", "home_team", "away_team"], keep=False)
    for _, r in match_log[dup_mask].iterrows():
        issues.append({"date": r["date"], "home_team": r["home_team"],
                        "away_team": r["away_team"], "issue": "Duplicate fixture row in the data"})

    return pd.DataFrame(issues, columns=["date", "home_team", "away_team", "issue"])


def write_data_quality_sheet(wb: Workbook, match_log: pd.DataFrame):
    """A short, hopefully-empty sheet: every fixture check_data_quality()
    flagged, or a clean bill of health if none did. Meant as a first stop
    before trusting a given run's numbers, not a replacement for the
    "Warning: N pre-match rows did not find a match" console output
    build_deltas.py already prints for fixtures that never made it into
    the CSV at all - this sheet can only check what's IN the data, not
    what's missing from it entirely."""
    ws = wb.create_sheet("Data Quality")
    issues_df = check_data_quality(match_log)

    ws.cell(row=1, column=1, value="Data Quality Checker").font = TITLE_FONT
    if issues_df.empty:
        ws.cell(row=3, column=1,
                value=f"No issues found across {len(match_log)} fixtures.").font = BOLD_FONT
        ws.column_dimensions["A"].width = 50
        return

    ws.cell(row=2, column=1,
            value=f"{len(issues_df)} issue(s) across {issues_df[['date', 'home_team', 'away_team']].drop_duplicates().shape[0]} "
                  f"fixture(s), out of {len(match_log)} total.").font = SUBTITLE_FONT

    headers = ["Date", "Home Team", "Away Team", "Issue"]
    header_row = 4
    for c, h in enumerate(headers, start=1):
        ws.cell(row=header_row, column=c, value=h)
    style_header_row(ws, header_row, len(headers))

    for r in issues_df.itertuples(index=False):
        ws.append([pd.to_datetime(r.date).strftime("%Y-%m-%d"), r.home_team, r.away_team, r.issue])

    last_row = ws.max_row
    for row in ws.iter_rows(min_row=header_row + 1, max_row=last_row, max_col=len(headers)):
        for cell in row:
            cell.font = BODY_FONT

    ws.auto_filter.ref = f"A{header_row}:{get_column_letter(len(headers))}{last_row}"
    ws.freeze_panes = f"A{header_row + 1}"
    autosize_columns(ws, len(headers), header_row=header_row, max_row=last_row, max_width=60)
    ws.column_dimensions["B"].width = max(ws.column_dimensions["B"].width, 14)
    ws.column_dimensions["C"].width = max(ws.column_dimensions["C"].width, 14)
    polish_sheet(ws, header_row=header_row, first_data_row=header_row + 1, last_data_row=last_row,
                 n_cols=len(headers))


def write_dashboard_sheet(wb: Workbook, n_teams: int):
    """League-wide charts, built AFTER Overview and xPts Table exist since
    every chart references their cells directly (live, not a snapshot - if
    you re-open and edit a number on Overview, the chart moves with it).

    Those referenced cells are themselves formulas (='TeamName'!$E$10 etc,
    not literal numbers) - openpyxl can't evaluate formulas itself, so a
    chart built this way renders blank/stale until Excel or Sheets
    recalculates the workbook, which both do automatically on first open.
    If a chart looks empty right after generation, open it in Excel/Sheets
    once and it'll populate."""
    ws = wb.create_sheet("Dashboard")
    ws.sheet_view.showGridLines = False
    ws.cell(row=1, column=1, value="League Dashboard").font = TITLE_FONT
    ws.cell(row=2, column=1, value="Charts reference Overview / xPts Table live - re-run the "
                                    "pipeline and they update automatically.").font = SUBTITLE_FONT

    overview = wb["Overview"]
    xpts_table = wb["xPts Table"]
    last = 1 + n_teams  # last data row on both Overview (sorted by Avg xG Delta For) and xPts Table

    def bar_chart(title, y_axis_title, source_ws, data_col, anchor, height=10, width=22):
        chart = BarChart()
        chart.type = "col"
        chart.title = title
        chart.y_axis.title = y_axis_title
        chart.x_axis.title = None
        chart.height, chart.width = height, width
        chart.legend = None
        data = Reference(source_ws, min_col=data_col, min_row=1, max_row=last)
        cats = Reference(source_ws, min_col=1, min_row=2, max_row=last)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        ws.add_chart(chart, anchor)

    # 1) League xG overperformance: every team's Avg xG Delta (For), in the
    # order Overview is already sorted (best attacking overperformance
    # first) - column E.
    bar_chart("Avg xG Delta (For) by Team", "xG Delta", overview, 5, "A4")

    # 2) Supremacy Delta by team - column M.
    bar_chart("Avg Supremacy Delta by Team", "Supremacy Delta", overview, 13, "A25")

    # 3) xPts (Actual) vs xPts (Market), grouped bar - columns D and E on
    # the xPts Table sheet (already sorted by Actual, highest first).
    chart3 = BarChart()
    chart3.type = "col"
    chart3.grouping = "clustered"
    chart3.title = "xPts: Actual vs Market"
    chart3.y_axis.title = "Expected Points"
    chart3.height, chart3.width = 10, 22
    data = Reference(xpts_table, min_col=4, max_col=5, min_row=1, max_row=last)
    cats = Reference(xpts_table, min_col=2, min_row=2, max_row=last)
    chart3.add_data(data, titles_from_data=True)
    chart3.set_categories(cats)
    ws.add_chart(chart3, "A46")

    ws.column_dimensions["A"].width = 4


def write_home_away_split_sheet(wb: Workbook, team_info: dict):
    """League-wide Total/Home/Away breakdown - supremacy first, goals
    second - one row per team, both tables in the same Total-avg-supremacy
    order so the two are easy to cross-reference."""
    ws = wb.create_sheet("Home & Away Splits")
    row_order = sorted(team_info.keys(),
                        key=lambda t: team_info[t]["stats"]["avg_supremacy"], reverse=True)

    ws.cell(row=1, column=1, value="Supremacy Delta - Total / Home / Away").font = BOLD_FONT
    ws.cell(row=1, column=1).fill = SECTION_FILL
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=7)
    sup_headers = ["Team", "Total Avg", "Total Median", "Home Avg", "Home Median", "Away Avg", "Away Median"]
    for c, h in enumerate(sup_headers, start=1):
        ws.cell(row=2, column=c, value=h)
    style_header_row(ws, 2, len(sup_headers))

    sup_width_hints = {i + 2: [] for i in range(6)}
    r = 2
    for team in row_order:
        s = team_info[team]["stats"]
        r += 1
        vals = [team, s["avg_supremacy"], s["median_supremacy"],
                s["home_avg_supremacy"], s["home_median_supremacy"],
                s["away_avg_supremacy"], s["away_median_supremacy"]]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=r, column=c, value=v)
            cell.font = BODY_FONT
            if c > 1:
                cell.number_format = "0.00"
        for i in range(6):
            sup_width_hints[i + 2].append(vals[i + 1])
    sup_last_row = r
    for col_idx in (2, 3, 4, 5, 6, 7):
        letter = get_column_letter(col_idx)
        color_scale_zero(ws, f"{letter}3:{letter}{sup_last_row}", invert=False)
    autosize_columns(ws, len(sup_headers), header_row=2, max_row=sup_last_row, width_hints=sup_width_hints)
    polish_sheet(ws, header_row=2, first_data_row=3, last_data_row=sup_last_row, n_cols=len(sup_headers))

    goals_header_row = sup_last_row + 2
    ws.cell(row=goals_header_row, column=1, value="Total Goals - Total / Home / Away").font = BOLD_FONT
    ws.cell(row=goals_header_row, column=1).fill = SECTION_FILL
    ws.merge_cells(start_row=goals_header_row, start_column=1, end_row=goals_header_row, end_column=7)
    goals_headers = ["Team", "Total GF", "Total GA", "Home GF", "Home GA", "Away GF", "Away GA"]
    for c, h in enumerate(goals_headers, start=1):
        ws.cell(row=goals_header_row + 1, column=c, value=h)
    style_header_row(ws, goals_header_row + 1, len(goals_headers))

    goals_width_hints = {i + 2: [] for i in range(6)}
    r = goals_header_row + 1
    for team in row_order:
        s = team_info[team]["stats"]
        r += 1
        vals = [team, s["gf"], s["ga"], s["home_gf"], s["home_ga"], s["away_gf"], s["away_ga"]]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row=r, column=c, value=v)
            cell.font = BODY_FONT
        for i in range(6):
            goals_width_hints[i + 2].append(vals[i + 1])
    goals_last_row = r
    autosize_columns(ws, len(goals_headers), header_row=goals_header_row + 1, max_row=goals_last_row,
                      width_hints=goals_width_hints)
    polish_sheet(ws, header_row=goals_header_row + 1, first_data_row=goals_header_row + 2,
                 last_data_row=goals_last_row, n_cols=len(goals_headers))
    ws.column_dimensions["A"].width = max(ws.column_dimensions["A"].width, 20)
    ws.freeze_panes = "A3"


def write_results_data_sheet(wb: Workbook, results_df: pd.DataFrame):
    """Raw backing data for the League Table - one row per played match.
    Kept as plain data (it's a straight import of source results), with
    the League Table's P/W/D/L/GF/GA/Pts all computed from it via formulas."""
    ws = wb.create_sheet("Results Data")
    ws.sheet_state = "hidden"
    headers = ["Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG"]
    ws.append(headers)
    style_header_row(ws, 1, len(headers))
    for _, r in results_df.iterrows():
        ws.append([
            pd.to_datetime(r["Date"], dayfirst=True).strftime("%Y-%m-%d"),
            normalise_name(r["HomeTeam"], TEAM_NAME_MAP),
            normalise_name(r["AwayTeam"], TEAM_NAME_MAP),
            int(r["FTHG"]), int(r["FTAG"]),
        ])
    autosize_columns(ws, len(headers))
    return ws.max_row  # last data row


def compute_standings(results_df: pd.DataFrame) -> pd.DataFrame:
    """League standings (points, then goal difference, then goals for) from the
    played-match results. Shared by the League Table sheet, the League Summary
    sheet and each team tab's closing-odds table so all three always agree on
    the order."""
    home = results_df.rename(columns={"HomeTeam": "team", "AwayTeam": "opponent",
                                       "FTHG": "gf", "FTAG": "ga"})[["team", "opponent", "gf", "ga"]]
    away = results_df.rename(columns={"AwayTeam": "team", "HomeTeam": "opponent",
                                       "FTAG": "gf", "FTHG": "ga"})[["team", "opponent", "gf", "ga"]]
    long_df = pd.concat([home, away], ignore_index=True)
    long_df["team"] = long_df["team"].apply(lambda n: normalise_name(n, TEAM_NAME_MAP))
    long_df["points"] = long_df.apply(lambda r: 3 if r.gf > r.ga else (1 if r.gf == r.ga else 0), axis=1)
    long_df["result"] = long_df.apply(lambda r: "W" if r.gf > r.ga else ("D" if r.gf == r.ga else "L"), axis=1)
    standings = (
        long_df.groupby("team")
        .agg(played=("gf", "count"), gf=("gf", "sum"), ga=("ga", "sum"), points=("points", "sum"),
             won=("result", lambda s: (s == "W").sum()),
             drawn=("result", lambda s: (s == "D").sum()),
             lost=("result", lambda s: (s == "L").sum()))
        .reset_index()
    )
    standings["gd"] = standings["gf"] - standings["ga"]
    standings = standings.sort_values(["points", "gd", "gf"], ascending=False).reset_index(drop=True)
    return standings


def write_league_table_sheet(wb: Workbook, results_df: pd.DataFrame, last_results_row: int):
    """Standard standings (P/W/D/L/GF/GA/GD/Pts), row order decided in
    Python (points, then goal difference, then goals for - the standard
    tie-break) but every number a formula against the 'Results Data' sheet,
    so it stays correct if that data is edited."""
    standings = compute_standings(results_df)

    ws = wb.create_sheet("League Table")
    headers = ["Pos", "Team", "P", "W", "D", "L", "GF", "GA", "GD", "Pts"]
    ws.append(headers)
    style_header_row(ws, 1, len(headers))

    def rd_range(letter):
        return f"'Results Data'!${letter}$2:${letter}${last_results_row}"

    home_team_rng = rd_range("B")
    away_team_rng = rd_range("C")
    home_gf_rng = rd_range("D")
    away_gf_rng = rd_range("E")

    for i, row in enumerate(standings.itertuples(), start=2):
        team = row.team
        ws.cell(row=i, column=1, value=f"=ROW()-1")                       # Pos
        ws.cell(row=i, column=2, value=team)                              # Team
        ws.cell(row=i, column=3,                                          # P
                value=f"=COUNTIF({home_team_rng},$B{i})+COUNTIF({away_team_rng},$B{i})")
        ws.cell(row=i, column=4,                                          # W
                value=(f"=SUMPRODUCT(({home_team_rng}=$B{i})*({home_gf_rng}>{away_gf_rng}))"
                       f"+SUMPRODUCT(({away_team_rng}=$B{i})*({away_gf_rng}>{home_gf_rng}))"))
        ws.cell(row=i, column=5,                                          # D
                value=(f"=SUMPRODUCT(({home_team_rng}=$B{i})*({home_gf_rng}={away_gf_rng}))"
                       f"+SUMPRODUCT(({away_team_rng}=$B{i})*({away_gf_rng}={home_gf_rng}))"))
        ws.cell(row=i, column=6, value=f"=C{i}-D{i}-E{i}")                # L
        ws.cell(row=i, column=7,                                          # GF
                value=f"=SUMIF({home_team_rng},$B{i},{home_gf_rng})+SUMIF({away_team_rng},$B{i},{away_gf_rng})")
        ws.cell(row=i, column=8,                                          # GA
                value=f"=SUMIF({home_team_rng},$B{i},{away_gf_rng})+SUMIF({away_team_rng},$B{i},{home_gf_rng})")
        ws.cell(row=i, column=9, value=f"=G{i}-H{i}")                     # GD
        ws.cell(row=i, column=10, value=f"=D{i}*3+E{i}")                  # Pts

    last_row = ws.max_row
    for row in ws.iter_rows(min_row=2, max_row=last_row, max_col=len(headers)):
        for cell in row:
            cell.font = BODY_FONT
            if cell.column == 1:
                cell.alignment = Alignment(horizontal="center")

    ws.freeze_panes = "A2"
    width_hints = {
        1: [len(standings)],                                     # Pos
        3: standings["played"].tolist(),                         # P
        4: standings["won"].tolist(),                             # W
        5: standings["drawn"].tolist(),                           # D
        6: standings["lost"].tolist(),                            # L
        7: standings["gf"].tolist(),                              # GF
        8: standings["ga"].tolist(),                              # GA
        9: standings["gd"].tolist(),                              # GD
        10: standings["points"].tolist(),                         # Pts
    }
    autosize_columns(ws, len(headers), width_hints=width_hints)
    ws.column_dimensions["B"].width = max(ws.column_dimensions["B"].width, 14)  # Team
    polish_sheet(ws, header_row=1, first_data_row=2, last_data_row=last_row, n_cols=len(headers))
    return ws


def write_matrix_sheet(wb: Workbook, sheet_name: str, team_info: dict,
                        values_by_team: dict, sort_key_by_team: dict,
                        source_col_header: str, avg_summary_label: str,
                        colored: bool, invert: bool, col_prefix: str = "MW",
                        formula_row_lookup: bool = True,
                        median_summary_label: str | None = None):
    """Teams down the left, one column per match (col_prefix + "1", "2",
    ...), plus an Average column, and - when median_summary_label is
    given - a Median column at the very end. Row order: DESCENDING by
    sort_key_by_team[team] (not necessarily the same stat as
    values_by_team - e.g. the Home/Away Supremacy Delta grids are sorted
    by their OWN home/away average rather than the Total grid's, so a
    team can rank differently across the three; see the About This
    Report sheet).

    When formula_row_lookup is True (the full-season grids), every match
    cell is a formula referencing that team's own sheet at a fixed row
    (source_col_header column, MW-th data row) - correct because the
    full-season grid's column N always means "this team's Nth match
    overall", matching the team sheet's own row order. The Home-only /
    Away-only grids can't use that trick (a team's home matches are
    scattered among its sheet's rows, not contiguous), so
    formula_row_lookup=False writes the values_by_team numbers directly
    instead - a Python-computed snapshot, not a live formula, same
    trade-off as the Home/Away split table on each team sheet. The
    Median column (when requested) is always a formula, referencing the
    team sheet's own median summary row - the Home/Away grids don't
    request one since there's no per-side median in the summary block."""
    max_matches = max((len(v) for v in values_by_team.values()), default=0)
    sorted_teams = sorted(values_by_team.keys(), key=lambda t: sort_key_by_team[t], reverse=True)

    ws = wb.create_sheet(sheet_name)
    headers = ["Team", "Average"] + [f"{col_prefix}{i}" for i in range(1, max_matches + 1)]
    if median_summary_label:
        headers.append("Median")
    ws.append(headers)
    style_header_row(ws, 1, len(headers))
    ws.cell(row=1, column=1).comment = Comment(MW_NOTE, "build_team_workbook.py")

    avg_by_team = {t: round(sum(v) / len(v), 2) if v else 0.0 for t, v in values_by_team.items()}
    width_hints = {2: [avg_by_team[t] for t in sorted_teams]}
    for mw in range(1, max_matches + 1):
        width_hints[mw + 2] = [v[mw - 1] for v in values_by_team.values() if len(v) >= mw]
    if median_summary_label:
        width_hints[len(headers)] = [
            round(pd.Series(v).median(), 2) for v in values_by_team.values() if v
        ]

    for row_i, team in enumerate(sorted_teams, start=2):
        info = team_info[team]
        n = len(values_by_team[team])

        ws.cell(row=row_i, column=1, value=team).font = BODY_FONT
        if formula_row_lookup:
            sheet_ref = info["sheet_name"]
            avg_row = info["summary_rows"][avg_summary_label]
            avg_cell = ws.cell(row=row_i, column=2, value=f"='{sheet_ref}'!$E${avg_row}")
        else:
            avg_cell = ws.cell(row=row_i, column=2, value=avg_by_team[team])
        avg_cell.font = BOLD_FONT
        avg_cell.number_format = "0.00"
        avg_cell.fill = SUMMARY_FILL

        for mw in range(1, max_matches + 1):
            col = mw + 2
            cell = ws.cell(row=row_i, column=col)
            if mw <= n:
                if formula_row_lookup:
                    sheet_ref = info["sheet_name"]
                    metric_letter = info["col_letter"][source_col_header]
                    data_row = mw + 1  # row 2 on the team sheet = MW1
                    cell.value = f"='{sheet_ref}'!${metric_letter}${data_row}"
                else:
                    cell.value = values_by_team[team][mw - 1]
                cell.number_format = "0.00"
            cell.font = BODY_FONT

        if median_summary_label:
            median_row = info["summary_rows"][median_summary_label]
            median_cell = ws.cell(row=row_i, column=len(headers), value=f"='{info['sheet_name']}'!$E${median_row}")
            median_cell.font = BOLD_FONT
            median_cell.number_format = "0.00"
            median_cell.fill = SUMMARY_FILL

    last_row = ws.max_row
    last_col_letter = get_column_letter(len(headers))
    if colored and last_row >= 2:
        color_scale_zero(ws, f"B2:{last_col_letter}{last_row}", invert=invert)

    ws.freeze_panes = "C2"  # keep Team + Average visible while scrolling across matchweeks
    autosize_columns(ws, len(headers), width_hints=width_hints)
    ws.column_dimensions["A"].width = max(ws.column_dimensions["A"].width, 20)  # Team
    polish_sheet(ws, header_row=1, first_data_row=2, last_data_row=last_row, n_cols=len(headers), band=False)
    return ws


def write_fixtures_sheet(wb: Workbook, fixtures_df: pd.DataFrame, team_info: dict):
    """Upcoming fixtures ranked by an "expected supremacy" for the home
    side that blends the market's own pre-match view of THIS fixture with
    how much each team has been beating/missing its own expectation all
    season:

        Combined Expected Supremacy (Home)
          = Market Pre-Match Supremacy (Home)
            + Home Team's Season Avg Supremacy Delta
            - Away Team's Season Avg Supremacy Delta

    where Market Pre-Match Supremacy (Home) = xg_pre_market_home -
    xg_pre_market_away, i.e. what the odds alone say about this specific
    match. Expected TOTAL goals uses the same blending idea, but summed
    rather than subtracted - a high-scoring team pushes the total up
    whichever side of the fixture it's on:

        Combined Expected Total Goals
          = Market Pre-Match Total xG (both sides combined)
            + Home Team's Season Avg Total xG Delta
            + Away Team's Season Avg Total xG Delta

    A team with no season data yet (e.g. just promoted, or not yet
    covered by team_match_deltas) contributes 0 to its side of either
    adjustment and is flagged in the Notes column, rather than the whole
    row being dropped.

    Both combined estimates get a data bar (not just a colour scale) so
    the size and direction of the lean is visible without reading the
    number - a longer bar is a stronger lean, and (Excel/Sheets' own
    behaviour, not something set here) a column whose values cross zero
    gets bars in both directions from a centre axis automatically."""
    ws = wb.create_sheet("Upcoming Fixtures")
    headers = ["Date", "Home Team", "Away Team",
               "Market Pre-Match Supremacy (Home)", "Home Team Season Avg Supremacy",
               "Away Team Season Avg Supremacy", "Combined Expected Supremacy (Home)",
               "Market Pre-Match Total xG", "Home Team Season Avg Total xG Delta",
               "Away Team Season Avg Total xG Delta", "Combined Expected Total Goals",
               "Notes"]
    ws.append(headers)
    style_header_row(ws, 1, len(headers))

    rows = []
    for _, r in fixtures_df.iterrows():
        home_norm = normalise_name(r["home_team"], TEAM_NAME_MAP)
        away_norm = normalise_name(r["away_team"], TEAM_NAME_MAP)
        market_supremacy = round(r["xg_pre_market_home"] - r["xg_pre_market_away"], 2)
        market_total = round(r["xg_pre_market_home"] + r["xg_pre_market_away"], 2)

        notes = []
        home_stats = team_info.get(home_norm, {}).get("stats")
        away_stats = team_info.get(away_norm, {}).get("stats")
        home_avg_sup = home_stats["avg_supremacy"] if home_stats else 0.0
        away_avg_sup = away_stats["avg_supremacy"] if away_stats else 0.0
        home_avg_total = home_stats["avg_total_delta"] if home_stats else 0.0
        away_avg_total = away_stats["avg_total_delta"] if away_stats else 0.0
        if not home_stats:
            notes.append(f"No season data yet for {home_norm}")
        if not away_stats:
            notes.append(f"No season data yet for {away_norm}")
        combined_supremacy = round(market_supremacy + home_avg_sup - away_avg_sup, 2)
        combined_total = round(market_total + home_avg_total + away_avg_total, 2)

        date_val = r.get("date")
        try:
            date_str = pd.to_datetime(date_val).strftime("%Y-%m-%d")
        except (ValueError, TypeError):
            date_str = str(date_val)

        rows.append((date_str, home_norm, away_norm, market_supremacy, home_avg_sup, away_avg_sup,
                     combined_supremacy, market_total, home_avg_total, away_avg_total, combined_total,
                     "; ".join(notes)))

    rows.sort(key=lambda row: row[6], reverse=True)

    width_hints = {i + 1: [] for i in range(len(headers))}
    for row_vals in rows:
        ws.append(list(row_vals))
        for i, v in enumerate(row_vals, start=1):
            width_hints[i].append(v)

    last_row = ws.max_row
    decimal_cols = {4, 5, 6, 7, 8, 9, 10, 11}
    for row in ws.iter_rows(min_row=2, max_row=last_row, max_col=len(headers)):
        for cell in row:
            cell.font = BODY_FONT
            if cell.column in decimal_cols:
                cell.number_format = "0.00"

    if last_row >= 2:
        # Supremacy is signed (home-favoured vs away-favoured), so it keeps
        # the red/white/green colour scale underneath a gold bar - the
        # colour gives direction at a glance, the bar gives magnitude.
        # Total goals has no "good" direction, just a bigger/smaller
        # number, so it gets a plain bar with no colour scale.
        ws.conditional_formatting.add(
            f"G2:G{last_row}",
            DataBarRule(start_type="min", end_type="max", color="C9A227", showValue=True),
        )
        color_scale_zero(ws, f"G2:G{last_row}", invert=False)
        ws.conditional_formatting.add(
            f"K2:K{last_row}",
            DataBarRule(start_type="min", end_type="max", color="6FA588", showValue=True),
        )

    ws.freeze_panes = "A2"
    autosize_columns(ws, len(headers), width_hints=width_hints, max_width=40)
    polish_sheet(ws, header_row=1, first_data_row=2, last_data_row=last_row, n_cols=len(headers))
    return ws


def build_odds_lookup(results_df: pd.DataFrame) -> dict:
    """{(home_team, away_team): {...}} for every played match, with names
    normalised the same way as the team tabs. Holds the closing home/draw/away
    prices (first available source in CLOSING_ODDS_COLS) plus the score, so a
    team tab can show its own win price for each fixture and colour it by the
    result."""
    lookup = {}
    for _, r in results_df.iterrows():
        home = normalise_name(r["HomeTeam"], TEAM_NAME_MAP)
        away = normalise_name(r["AwayTeam"], TEAM_NAME_MAP)
        odds = (None, None, None)
        for h_col, d_col, a_col in CLOSING_ODDS_COLS:
            if h_col in r.index and a_col in r.index and pd.notna(r[h_col]) and pd.notna(r[a_col]):
                odds = (float(r[h_col]), float(r[d_col]) if d_col in r.index and pd.notna(r[d_col]) else None,
                        float(r[a_col]))
                break
        lookup[(home, away)] = {"home_odds": odds[0], "draw_odds": odds[1], "away_odds": odds[2],
                                "hg": int(r["FTHG"]), "ag": int(r["FTAG"])}
    return lookup


def _hdr(cell):
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="center", wrap_text=True, vertical="center")
    cell.border = THIN_BORDER


def write_team_extras(ws: Worksheet, team: str, n_cols: int, n_matches: int, last_row: int,
                      col_letter: dict, odds_lookup: dict | None, table_order: list | None):
    """Everything added to the right of a team tab's match table (one blank
    column after it):

      1. Over/under-expected game counts (xG and goals, for and against).
      2. A separate gameweek table (Goals For, Goals Against shown as a
         negative, and the pre-match expected goals for and against - kept
         apart from the actual-xG columns in the main match table).
      3. A bar chart off that table: goals for ABOVE the zero line, goals
         against BELOW it, one pair of bars per gameweek (MW1, MW2...), with a
         dashed line across each side showing what was expected.
      4. A league-table-ordered closing-odds table: this team's own closing
         price to win each fixture, split into the home fixture and the away
         fixture against each opponent, filled green (won) / amber (drew) /
         red (lost).

    \"Expected\" = the pre-match market xG (the goals the odds implied for each
    side) - the same numbers as the \"xG Pre-Match\" columns of the match table.
    Every number here is a formula pointing back at the match table, apart
    from the closing odds (raw data from the results file) and the results
    colours (static fills - the whole workbook is rebuilt each run)."""
    c0 = n_cols + 2
    L = get_column_letter
    gf, ga = col_letter["Goals For"], col_letter["Goals Against"]
    pf, pa = col_letter["xG Pre-Match (For)"], col_letter["xG Pre-Match (Against)"]
    dxf, dxa = col_letter["xG Delta (For)"], col_letter["xG Delta (Against)"]

    def rng(letter):
        return f"${letter}$2:${letter}${last_row}"

    # --- title + counts ---------------------------------------------------
    ws.cell(row=1, column=c0, value="Goals vs expected").font = TITLE_FONT
    ws.cell(row=2, column=c0, value="Expected = the pre-match market xG (what the odds implied) for each side.").font = SUBTITLE_FONT
    for i, h in enumerate(["Games vs expected", "Above", "Below"]):
        _hdr(ws.cell(row=3, column=c0 + i, value=h))
    count_rows = [
        ("xG For vs expected", f'=COUNTIF({rng(dxf)},">0")', f'=COUNTIF({rng(dxf)},"<0")'),
        ("xG Against vs expected", f'=COUNTIF({rng(dxa)},">0")', f'=COUNTIF({rng(dxa)},"<0")'),
        ("Goals For vs expected", f"=SUMPRODUCT(--({rng(gf)}>{rng(pf)}))", f"=SUMPRODUCT(--({rng(gf)}<{rng(pf)}))"),
        ("Goals Against vs expected", f"=SUMPRODUCT(--({rng(ga)}>{rng(pa)}))", f"=SUMPRODUCT(--({rng(ga)}<{rng(pa)}))"),
    ]
    for i, (label, above, below) in enumerate(count_rows):
        r = 4 + i
        for j, v in enumerate((label, above, below)):
            cell = ws.cell(row=r, column=c0 + j, value=v)
            cell.font = BODY_FONT
            cell.border = THIN_BORDER
            if j:
                cell.alignment = Alignment(horizontal="center")
    ws.cell(row=8, column=c0,
            value="For: Above = beat expectation. Against: Above = conceded more than expected (worse).").font = SUBTITLE_FONT

    # --- gameweek table (chart source) ------------------------------------
    hr = 10
    ws.cell(row=hr - 1, column=c0,
            value="Chart data: Against figures are stored as negatives so they plot below the zero line.").font = SUBTITLE_FONT
    for i, h in enumerate(["Gameweek", "Goals For", "Goals Against", "Expected Goals For", "Expected Goals Against"]):
        _hdr(ws.cell(row=hr, column=c0 + i, value=h))
    ws.row_dimensions[hr].height = 30
    for i in range(n_matches):
        r, mr = hr + 1 + i, 2 + i
        vals = [f"MW{i + 1}", f"={gf}{mr}", f"=-{ga}{mr}", f"={pf}{mr}", f"=-{pa}{mr}"]
        for j, v in enumerate(vals):
            cell = ws.cell(row=r, column=c0 + j, value=v)
            cell.font = BODY_FONT
            cell.border = THIN_BORDER
            if j:
                cell.number_format = "0;-0;0" if j in (1, 2) else "0.00"
                cell.alignment = Alignment(horizontal="center")

    # --- chart --------------------------------------------------------------
    bar = BarChart()
    bar.type = "col"
    bar.grouping = "clustered"
    bar.overlap = 100  # goals for and against share one x position, one up, one down
    bar.gapWidth = 60
    bar.add_data(Reference(ws, min_col=c0 + 1, max_col=c0 + 2, min_row=hr, max_row=hr + n_matches),
                 titles_from_data=True)
    cats = Reference(ws, min_col=c0, min_row=hr + 1, max_row=hr + n_matches)
    bar.set_categories(cats)
    bar.series[0].graphicalProperties.solidFill = "5B9BD5"
    bar.series[1].graphicalProperties.solidFill = "ED7D31"

    line = LineChart()
    line.add_data(Reference(ws, min_col=c0 + 3, max_col=c0 + 4, min_row=hr, max_row=hr + n_matches),
                  titles_from_data=True)
    line.set_categories(cats)
    for s_, colour in zip(line.series, ("000000", "595959")):
        s_.graphicalProperties.line.solidFill = colour
        s_.graphicalProperties.line.width = 22000
        s_.graphicalProperties.line.dashStyle = "dash"
        s_.marker.symbol = "circle"
        s_.marker.size = 6
        s_.marker.graphicalProperties.solidFill = colour
        s_.marker.graphicalProperties.line.solidFill = colour
        s_.smooth = False

    bar.title = f"{team}: goals for (above) and against (below) vs expected"
    bar.y_axis.title = "Goals"
    bar.y_axis.number_format = "0;0;0"  # show goals against as a positive count below the axis
    bar.x_axis.tickLblPos = "low"       # gameweek labels along the bottom, not on the zero line
    bar.x_axis.delete = False
    bar.y_axis.delete = False
    bar.legend.position = "b"
    bar += line
    bar.height, bar.width = 10, 26
    chart_col = c0 + 6
    ws.add_chart(bar, f"{L(chart_col)}2")

    # --- closing-odds table, league-table order ---------------------------
    if odds_lookup is None or not table_order:
        return
    ot = 24
    ws.cell(row=ot - 1, column=chart_col,
            value=f"{team}: closing odds to win, by opponent (league table order)").font = BOLD_FONT
    for i, h in enumerate(["League Table", "Home Odds", "Away Odds"]):
        _hdr(ws.cell(row=ot, column=chart_col + i, value=h))
    for i, opp in enumerate(table_order):
        r = ot + 1 + i
        name_cell = ws.cell(row=r, column=chart_col, value=f"{i + 1}. {opp}")
        name_cell.font = BOLD_FONT if opp == team else BODY_FONT
        name_cell.border = THIN_BORDER
        for j in (1, 2):
            c = ws.cell(row=r, column=chart_col + j)
            c.font = BODY_FONT
            c.border = THIN_BORDER
            c.number_format = "0.00"
            c.alignment = Alignment(horizontal="center")
            if opp == team:
                c.fill = GREY_FILL
        if opp == team:
            name_cell.fill = GREY_FILL
            continue
        home_fx = odds_lookup.get((team, opp))   # fixture at this team's ground
        away_fx = odds_lookup.get((opp, team))   # fixture at the opponent's ground
        if home_fx:
            c = ws.cell(row=r, column=chart_col + 1, value=home_fx["home_odds"])
            res = "W" if home_fx["hg"] > home_fx["ag"] else ("D" if home_fx["hg"] == home_fx["ag"] else "L")
            c.fill = RESULT_FILLS[res]
        if away_fx:
            c = ws.cell(row=r, column=chart_col + 2, value=away_fx["away_odds"])
            res = "W" if away_fx["ag"] > away_fx["hg"] else ("D" if away_fx["ag"] == away_fx["hg"] else "L")
            c.fill = RESULT_FILLS[res]

    leg = ot + len(table_order) + 2
    for k, (res, label) in enumerate((("W", "Won"), ("D", "Drew"), ("L", "Lost"))):
        ws.cell(row=leg + k, column=chart_col).fill = RESULT_FILLS[res]
        ws.cell(row=leg + k, column=chart_col, value=label).font = BODY_FONT
    ws.cell(row=leg + 3, column=chart_col,
            value="Odds = this team's own closing price to win that fixture. Home Odds = the game at this "
                  "team's ground; Away Odds = the game at the opponent's.").font = SUBTITLE_FONT
    ws.cell(row=leg + 4, column=chart_col,
            value="Source: football-data.co.uk Pinnacle closing odds (market-average closing if Pinnacle is "
                  "missing). Blank = not played yet.").font = SUBTITLE_FONT

    ws.column_dimensions[L(c0)].width = 30
    for j in range(1, 5):
        ws.column_dimensions[L(c0 + j)].width = 16
    ws.column_dimensions[L(c0 + 5)].width = 3
    ws.column_dimensions[L(chart_col)].width = 30
    ws.column_dimensions[L(chart_col + 1)].width = 12
    ws.column_dimensions[L(chart_col + 2)].width = 12


def write_league_summary_sheet(wb: Workbook, team_info: dict, standings: pd.DataFrame):
    """One row per team, in league-table order. Ranks are 1 = best and are
    RANK() formulas over the value columns on the right (K:O), which are
    themselves formulas into each team's tab - so the sheet recalculates with
    the rest of the workbook."""
    ws = wb.create_sheet("League Summary")
    headers = ["Team", "League Position", "Games Played",
               "Goals For Supremacy Rank", "Goals Conceded Supremacy Rank",
               "Goals Above Expected (Total) Rank", "xPts Delta Rank", "Market Points Rank",
               "Games +ve xG Supremacy", "Games -ve xG Supremacy",
               "Avg xG Delta (For)", "Avg xG Delta (Against)", "Avg Total xG Delta",
               "xPts Delta (Total)", "Market xPts (Total)"]
    ws.append(headers)
    style_header_row(ws, 1, len(headers))
    ws.row_dimensions[1].height = 48

    order = [t for t in standings["team"] if t in team_info] + [t for t in team_info if t not in set(standings["team"])]
    n = len(order)
    last = n + 1
    lt_last = len(standings) + 1
    has_table = "League Table" in wb.sheetnames
    for i, team in enumerate(order):
        r = i + 2
        info = team_info[team]
        sh, sr, cl = info["sheet_name"], info["summary_rows"], info["col_letter"]
        sup = cl["Supremacy Delta"]
        last_m = info["n_matches"] + 1
        if has_table:
            pos = f"=IFERROR(INDEX('League Table'!$A$2:$A${lt_last},MATCH($A{r},'League Table'!$B$2:$B${lt_last},0)),\"\")"
            gp = f"=IFERROR(INDEX('League Table'!$C$2:$C${lt_last},MATCH($A{r},'League Table'!$B$2:$B${lt_last},0)),\"\")"
        else:
            pos, gp = "", f"='{sh}'!$E${sr['Matches played']}"
        ws.append([
            team, pos, gp,
            f"=RANK(K{r},K$2:K${last},0)",       # attack: more xG than expected = best
            f"=RANK(L{r},L$2:L${last},1)",       # defence: most NEGATIVE delta = rank 1
            f"=RANK(M{r},M$2:M${last},0)",       # total xG above expectation, highest = 1
            f"=RANK(N{r},N$2:N${last},0)",
            f"=RANK(O{r},O$2:O${last},0)",
            f"=COUNTIF('{sh}'!${sup}$2:${sup}${last_m},\">0\")",
            f"=COUNTIF('{sh}'!${sup}$2:${sup}${last_m},\"<0\")",
            # ROUND(...,4): exact ties (identical averages that differ only by
            # floating-point noise) must share a rank, not be split arbitrarily.
            f"=ROUND('{sh}'!$E${sr['Avg xG Delta (For)']},4)",
            f"=ROUND('{sh}'!$E${sr['Avg xG Delta (Against)']},4)",
            f"=ROUND('{sh}'!$E${sr['Avg Total xG Delta']},4)",
            f"=ROUND('{sh}'!$E${sr['Total xPts (Actual)']}-'{sh}'!$E${sr['Total xPts (Market)']},4)",
            f"=ROUND('{sh}'!$E${sr['Total xPts (Market)']},4)",
        ])

    for row in ws.iter_rows(min_row=2, max_row=last, max_col=len(headers)):
        for cell in row:
            cell.font = BODY_FONT
            if 2 <= cell.column <= 10:
                cell.alignment = Alignment(horizontal="center")
            if cell.column >= 11:
                cell.number_format = "0.00"
    for col in range(1, len(headers) + 1):
        ws.cell(row=1, column=col).font = HEADER_FONT

    for letter in "DEFGH":
        color_scale(ws, f"{letter}2:{letter}{last}", invert=True)   # rank 1 = green
    ws.conditional_formatting.add(f"I2:I{last}", ColorScaleRule(
        start_type="min", start_color=WHITE, end_type="max", end_color=GREEN))
    ws.conditional_formatting.add(f"J2:J{last}", ColorScaleRule(
        start_type="min", start_color=WHITE, end_type="max", end_color=RED))

    notes = [
        "How to read this sheet",
        "Ranks: 1 = best. Rows are in league-table order (position and games played come from the League Table sheet).",
        "Goals For Supremacy Rank: avg xG Delta (For) - actual xG for minus the pre-match market xG for. Highest = rank 1.",
        "Goals Conceded Supremacy Rank: avg xG Delta (Against) - actual xG against minus pre-match market xG against. "
        "The more negative (conceding less than expected), the better the rank, so the most negative = rank 1.",
        "Goals Above Expected (Total) Rank: avg Match Total xG Delta - combined actual xG in the team's games minus the combined "
        "pre-match market xG. Highest = rank 1 (games producing the most goals above expectation).",
        "xPts Delta Rank: season-total actual xPts minus market xPts. Highest = rank 1.   Market Points Rank: season-total market xPts, highest = rank 1.",
        "Games +ve / -ve xG Supremacy: games where the team's Supremacy Delta (actual xG supremacy minus pre-match expected supremacy) was above / below zero.",
        "Columns K:O hold the underlying numbers the ranks are calculated from.",
    ]
    for k, text in enumerate(notes):
        c = ws.cell(row=last + 2 + k, column=1, value=text)
        c.font = BOLD_FONT if k == 0 else SUBTITLE_FONT

    ws.freeze_panes = "B2"
    ws.column_dimensions["A"].width = 22
    for col in range(2, len(headers) + 1):
        ws.column_dimensions[get_column_letter(col)].width = 14
    polish_sheet(ws, header_row=1, first_data_row=2, last_data_row=last, n_cols=len(headers))
    return ws


def write_about_sheet(wb: Workbook, league_note: str | None = None):
    ws = wb.create_sheet("About This Report")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 100

    ws.cell(row=1, column=1, value="About This Report").font = TITLE_FONT
    r = 3
    paragraphs = [
        ("Sheets in this workbook", BOLD_FONT),
        ("League Table - standard standings from every played match.", BODY_FONT),
        ("League Summary - one row per team in league-table order: league position, games played, ranks (1 = best) for "
         "goals-for supremacy, goals-conceded supremacy, total goals above expected, xPts delta and market points, plus the "
         "number of games with positive and negative xG supremacy. The numbers behind the ranks sit in columns K:O.", BODY_FONT),
        ("Overview - a deliberately narrow at-a-glance summary of each team's core xG/xPts form, sorted by Avg xG "
         "Delta (For), best first. Medians, adjusted current form, and a couple of stats already shown elsewhere "
         "are left off - see the team tabs and the dedicated grid sheets for the full detail.", BODY_FONT),
        ("xPts Table - teams ranked by season-total xPts Delta (actual deserved points minus what the market "
         "expected), highest over-performance first - a \"truer\" table than the real one below since it's driven "
         "by chance quality rather than which chances actually went in.", BODY_FONT),
        ("Dashboard - three league-wide charts (xG Delta For, Supremacy Delta, xPts Actual vs Market) so patterns "
         "are visible at a glance instead of scrolling through team tabs.", BODY_FONT),
        ("Data Quality - flags fixtures with missing/negative xG or goals, or suspicious exact-0.00 xG on both "
         "sides - a first stop before trusting a given run's numbers.", BODY_FONT),
        ("Match Log - the single master data table: one row per fixture (not per team) with every core stat, "
         "and an AutoFilter so you can filter by team/venue without hunting through team tabs.", BODY_FONT),
        ("Home & Away Splits - Total/Home/Away average and median supremacy, and Total/Home/Away goals, for every team.", BODY_FONT),
        ("Supremacy Delta / (Home) / (Away) - match-by-match grids of actual vs. expected xG supremacy, each "
         "sorted by its own average, highest first.", BODY_FONT),
        ("Total xG Delta - match-by-match grid of how much higher/lower-scoring each match was than the market "
         "expected, sorted by its own average, with a Median column at the end.", BODY_FONT),
        ("xPts Delta - match-by-match grid of expected-points over/under-performance, sorted by its own average.", BODY_FONT),
        ("Upcoming Fixtures - ranked by expected supremacy (see below for how); also estimates each fixture's "
         "total goals, with both estimates shown as in-cell data bars for an at-a-glance visual read.", BODY_FONT),
        ("One tab per team - full match log, season summary (average AND median of every delta stat), and a Home/Away split table. "
         "To the right of the match table: counts of games above/below expected, a goals-for (above the line) / goals-against "
         "(below the line) bar chart per gameweek with the expected goals as a dashed line, and a league-table-ordered table of "
         "closing odds coloured green/amber/red for a win/draw/defeat.", BODY_FONT),
        ("", BODY_FONT),
        ("Judgement calls made where the brief was ambiguous", BOLD_FONT),
        ("\u2022 \"In order of xG for\": Overview is sorted by Avg xG Delta (For), highest (most attacking "
         "overperformance) first. The Supremacy Delta / Total xG Delta / xPts Delta grids are each sorted by "
         "their OWN average instead, highest first - including the Home-only and Away-only Supremacy grids, "
         "which use their own home-only / away-only average rather than the main grid's.", BODY_FONT),
        ("\u2022 Conditional formatting on every delta-style column is zero-anchored (green above 0, red below 0, "
         "white at exactly 0) rather than relative to that column's own min/max/median - 0 has a real meaning here "
         "(\"exactly as the market expected\"), so it's a fixed reference point rather than a moving one.", BODY_FONT),
        ("\u2022 Upcoming Fixtures' \"Combined Expected Supremacy (Home)\" = the market's own pre-match supremacy for "
         "that specific fixture, adjusted by how much each side has been over/under-performing its own expectation "
         "all season (home team's season average added, away team's season average subtracted). \"Combined "
         "Expected Total Goals\" uses the same blend but summed rather than subtracted, since either side being "
         "high-scoring pushes the total up. Both are simple, transparent blends - not a fitted model - so treat "
         "them as a way to surface interesting fixtures, not a prediction.", BODY_FONT),
        ("\u2022 xPts (expected points) use an independent-Poisson scoreline model - each side's goals treated as "
         "Poisson-distributed around its xG, win/draw/loss probabilities computed from that, then "
         "3\u00d7P(win) + 1\u00d7P(draw). It's the standard, simple way to turn two xG numbers into a points "
         "estimate - not fitted to this league's actual scoring distribution - so treat xPts Delta as a useful "
         "signal, not a precise number.", BODY_FONT),
        ("\u2022 The Supremacy Delta (Home) / (Away) grids are literal snapshots (computed once, at report-generation "
         "time) rather than live formulas like the full-season grid, since a team's home-only matches aren't a "
         "contiguous block of rows on its own sheet. Re-run the pipeline to refresh them.", BODY_FONT),
    ]
    for text, font in paragraphs:
        cell = ws.cell(row=r, column=1, value=text)
        cell.font = font
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        # Column A is 100 units wide (~90 characters per wrapped line at
        # this font size) - estimate how many lines this text will wrap
        # to and size the row for that, rather than a fixed height that
        # only fit the (shorter) original paragraphs and let newer, longer
        # ones overlap the row below.
        chars_per_line = 90
        n_lines = max(1, -(-len(text) // chars_per_line)) if text else 1  # ceil division
        ws.row_dimensions[r].height = max(30, n_lines * 15) if text else 8
        r += 1

    if league_note:
        r += 1
        cell = ws.cell(row=r, column=1, value=league_note)
        cell.font = SUBTITLE_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[r].height = 45


def main(input_path, results_path, output_path, rolling_window, fixtures_path=None, league_note=None):
    # format="mixed": defensive, not strictly needed here (build_deltas.py
    # writes this file with dates already normalised to plain YYYY-MM-DD,
    # a single consistent format) - but it's what actually broke
    # build_deltas.py's own date read on raw FotMob data (see the comment
    # in load_and_merge), so applying it here too costs nothing and rules
    # out the same failure mode if this file is ever hand-edited or
    # produced by something else.
    df = pd.read_csv(input_path)
    df["date"] = pd.to_datetime(df["date"], format="mixed", utc=True).dt.tz_localize(None)
    teams = sorted(df["team"].unique())

    wb = Workbook()
    wb.remove(wb.active)  # drop the default blank sheet

    write_about_sheet(wb, league_note=league_note)

    odds_lookup, table_order, standings = None, None, None
    if results_path:
        results_df = pd.read_csv(results_path, encoding="utf-8-sig")
        results_df = results_df.dropna(subset=["FTHG", "FTAG"])  # only played matches
        last_results_row = write_results_data_sheet(wb, results_df)
        write_league_table_sheet(wb, results_df, last_results_row)
        standings = compute_standings(results_df)
        table_order = standings["team"].tolist()
        odds_lookup = build_odds_lookup(results_df)

    used_names = set()
    team_info = {}
    supremacy_by_team, total_delta_by_team = {}, {}
    home_supremacy_by_team, away_supremacy_by_team = {}, {}
    xpts_delta_by_team = {}
    for team in teams:
        sheet_name = safe_sheet_name(team, used_names)
        team_df = df[df["team"] == team].sort_values("date")
        info = write_team_sheet(wb, sheet_name, team_df, rolling_window,
                                odds_lookup=odds_lookup, table_order=table_order)
        team_info[team] = info

        supremacy_by_team[team] = info["supremacy_series"]
        total_delta_by_team[team] = info["total_series"]
        home_supremacy_by_team[team] = info["home_supremacy_series"]
        away_supremacy_by_team[team] = info["away_supremacy_series"]
        xpts_delta_by_team[team] = info["xpts_delta_series"]

    if standings is not None:
        write_league_summary_sheet(wb, team_info, standings)
    write_overview_sheet(wb, team_info, rolling_window)
    write_xpts_table_sheet(wb, team_info)
    write_dashboard_sheet(wb, len(teams))
    match_log = build_match_log(df)
    write_match_log_sheet(wb, match_log)
    write_data_quality_sheet(wb, match_log)
    write_home_away_split_sheet(wb, team_info)

    avg_total_by_team = {t: team_info[t]["stats"]["avg_total_delta"] for t in teams}
    avg_supremacy_by_team = {t: team_info[t]["stats"]["avg_supremacy"] for t in teams}
    home_avg_supremacy_by_team = {t: team_info[t]["stats"]["home_avg_supremacy"] for t in teams}
    away_avg_supremacy_by_team = {t: team_info[t]["stats"]["away_avg_supremacy"] for t in teams}
    avg_xpts_delta_by_team = {t: team_info[t]["stats"]["avg_xpts_delta"] for t in teams}
    write_matrix_sheet(wb, "Supremacy Delta", team_info, supremacy_by_team,
                        sort_key_by_team=avg_supremacy_by_team,
                        source_col_header="Supremacy Delta", avg_summary_label="Avg Supremacy Delta",
                        colored=True, invert=False)
    write_matrix_sheet(wb, "Supremacy Delta (Home)", team_info, home_supremacy_by_team,
                        sort_key_by_team=home_avg_supremacy_by_team, source_col_header="Supremacy Delta",
                        avg_summary_label="Avg Supremacy Delta", colored=True, invert=False,
                        col_prefix="H", formula_row_lookup=False)
    write_matrix_sheet(wb, "Supremacy Delta (Away)", team_info, away_supremacy_by_team,
                        sort_key_by_team=away_avg_supremacy_by_team, source_col_header="Supremacy Delta",
                        avg_summary_label="Avg Supremacy Delta", colored=True, invert=False,
                        col_prefix="A", formula_row_lookup=False)
    write_matrix_sheet(wb, "Total xG Delta", team_info, total_delta_by_team, sort_key_by_team=avg_total_by_team,
                        source_col_header="Match Total xG Delta", avg_summary_label="Avg Total xG Delta",
                        colored=True, invert=False, median_summary_label="Median Total xG Delta")
    write_matrix_sheet(wb, "xPts Delta", team_info, xpts_delta_by_team, sort_key_by_team=avg_xpts_delta_by_team,
                        source_col_header="xPts Delta", avg_summary_label="Avg xPts Delta",
                        colored=True, invert=False)

    fixtures_sheet_written = False
    if fixtures_path:
        fixtures_df = pd.read_csv(fixtures_path)
        if not fixtures_df.empty:
            write_fixtures_sheet(wb, fixtures_df, team_info)
            fixtures_sheet_written = True
        else:
            print(f"'{fixtures_path}' has no rows - skipping the Upcoming Fixtures sheet.")

    # Sheet order: About, League Table, Overview, Home & Away Splits, the
    # grids, Upcoming Fixtures, then teams A-Z (Results Data stays hidden
    # but present).
    front = [n for n in ("About This Report", "League Table", "League Summary", "Overview", "xPts Table", "Dashboard",
                          "Data Quality", "Match Log",
                          "Home & Away Splits",
                          "Supremacy Delta", "Supremacy Delta (Home)", "Supremacy Delta (Away)",
                          "Total xG Delta", "xPts Delta", "Upcoming Fixtures") if n in wb.sheetnames]
    order = front + [n for n in wb.sheetnames if n not in front and n != "Results Data"]
    if "Results Data" in wb.sheetnames:
        order.append("Results Data")
    wb._sheets = [wb[n] for n in order]

    wb.save(output_path)
    extra = " + Upcoming Fixtures" if fixtures_sheet_written else ""
    print(f"Wrote workbook with {len(teams)} team sheets + League Table + Overview + xPts Table + Dashboard + "
          f"Data Quality + Match Log + "
          f"Home & Away Splits + Supremacy Delta (+ Home/Away) + Total xG Delta + xPts Delta{extra} to {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default="data/team_match_deltas.csv")
    parser.add_argument("--results", default="data/E1.csv",
                         help="Raw results file (for the League Table). Pass '' to skip the League Table.")
    parser.add_argument("--fixtures", default=None,
                         help="Pre-match xG file for upcoming fixtures (from download_fixtures.py + "
                              "derive_prematch_xg.py). Omit or pass '' to skip the Upcoming Fixtures sheet.")
    parser.add_argument("--output", default="data/championship_xg_report.xlsx")
    parser.add_argument("--rolling-window", type=int, default=6,
                         help="Only used to label the 'current form' column - must match what you passed to build_deltas.py")
    args = parser.parse_args()

    main(args.input, args.results or None, args.output, args.rolling_window, fixtures_path=args.fixtures or None)
